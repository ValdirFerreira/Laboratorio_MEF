﻿using GenericAutuacao;
using System;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;

namespace TesteMEF
{
    class Program
    {

        private CompositionContainer _container;

        [Import(typeof(IMulta))]
        private IMulta multa;
        private Program()
        {
            var catalog = new AggregateCatalog();
            catalog.Catalogs.Add(new AssemblyCatalog(typeof(Program).Assembly));
            catalog.Catalogs.Add(new DirectoryCatalog(@"../../libsMultas"));

            _container = new CompositionContainer(catalog);

            try
            {
                this._container.ComposeParts(this);
            }
            catch (CompositionException compositionException)
            {
                Console.WriteLine(compositionException.ToString());
            }
        }
        static void Main(string[] args)
        {
            Program p = new Program();
            if (p.multa.ModeloMulta() == "Multa São Paulo")
            {
                Console.WriteLine(p.multa.Imprimir());
            }
            else
            {
                Console.WriteLine("Multa não encontrada");
            }

            Console.ReadKey();
        }
    }
}

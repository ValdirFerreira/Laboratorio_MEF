﻿using GenericAutuacao;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Autuacao
{
    [Export(typeof(IMulta))]
    public class Autuacao : IMulta
    {
        private const string nomeMulta = "Multa São Paulo";

        public string Imprimir()
        {
            return "Impressão Gerada";
        }

        public string ModeloMulta()
        {
            return nomeMulta;
        }
    }
}
